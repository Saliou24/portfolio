package battleship.tir;


public class IntPair {

    final public int ligne;
    final public int colonne;

    public IntPair(int ligne, int colonne) {
        this.ligne = ligne;
        this.colonne = colonne;
    }
}