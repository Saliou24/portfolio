package battleship.enums;

public enum EtatChamp {
    enEtat,
    touché,
    pasEnEtat,
    raté,
    détruit,
    coulé,
    pasTouché;
}