package battleship.enums;


public enum Orientation {
    verticale,
    horizontale;

}
