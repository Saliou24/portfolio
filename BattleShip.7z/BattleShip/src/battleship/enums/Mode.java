package battleship.enums;

public enum Mode {
    soloCLASSIQUE,
    soloAVANCE,
    hotSeat1,
    hotSeat2,
    onlineServer,
    onlineClient;
}