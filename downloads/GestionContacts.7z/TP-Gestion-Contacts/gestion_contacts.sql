USE master 
GO
DROP DATABASE IF EXISTS gestion_contacts
GO
CREATE DATABASE gestion_contacts
GO
USE gestion_contacts

DROP TABLE IF EXISTS utilisateurs
CREATE TABLE utilisateurs(
	
	courriel varchar(255) UNIQUE, 	
	mot_de_passe varchar(50) NOT NULL,
	
)

INSERT INTO utilisateurs VALUES('Paul4@gmail.com', 'toto') 
INSERT INTO utilisateurs VALUES('Anne10@gmail.com', 'tata') 
INSERT INTO utilisateurs VALUES('Robert9@gmail.com', 'titi') 
INSERT INTO utilisateurs VALUES('David5@gmail.com', 'papa') 
INSERT INTO utilisateurs VALUES('Sophie8@gmail.com', 'maman') 
INSERT INTO utilisateurs VALUES('Jules2@gmail.com', '123') 
INSERT INTO utilisateurs VALUES('Jonathan6@gmail.com', 'abc') 
INSERT INTO utilisateurs VALUES('Khadija7@gmail.com', 'tonton') 
INSERT INTO utilisateurs VALUES('Jeanne3@gmail.com', 'null')
INSERT INTO utilisateurs VALUES('Charles1@gmail.com', 'moi')
INSERT INTO utilisateurs VALUES('Gerard11@gmail.com', 'toi') 
INSERT INTO utilisateurs VALUES('Alex12@gmail.com', 'lui') 
INSERT INTO utilisateurs VALUES('Emma13@gmail.com', 'elle') 
INSERT INTO utilisateurs VALUES('Julie14@gmail.com', 'nous') 
INSERT INTO utilisateurs VALUES('Rose15@gmail.com', 'leur') 
INSERT INTO utilisateurs VALUES('Jordi16@gmail.com', 'a') 
INSERT INTO utilisateurs VALUES('Juan17@gmail.com', 'b') 
INSERT INTO utilisateurs VALUES('Stephane18@gmail.com', 'c') 
INSERT INTO utilisateurs VALUES('Elisa19@gmail.com', 'd') 
INSERT INTO utilisateurs VALUES('Bernardo20@gmail.com', 'e') 
INSERT INTO utilisateurs VALUES('Kendall21@gmail.com', 'e') 
INSERT INTO utilisateurs VALUES('Adil22@gmail.com', 'e') 
INSERT INTO utilisateurs VALUES('Rene23@gmail.com', 'e') 
INSERT INTO utilisateurs VALUES('Philipe24@gmail.com', 'e') 
INSERT INTO utilisateurs VALUES('Jose25@gmail.com', 'e') 


DROP TABLE IF EXISTS contacts
CREATE TABLE contacts(
	id INT PRIMARY KEY CLUSTERED IDENTITY(1,1),
	nom varchar(50) NOT NULL,
	prenom varchar(50) NOT NULL,
	telephone char(50) CHECK (telephone LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]') NULL,
	courriel_utilisateur varchar(255) FOREIGN KEY REFERENCES utilisateurs(courriel) NULL

)


INSERT INTO contacts VALUES ('Charles ', 'Tressol','5144785890','Charles1@gmail.com')
INSERT INTO contacts VALUES ('Jules', 'Kounde','4387539331','Jules2@gmail.com')
INSERT INTO contacts VALUES ('Jeanne', 'Adelaide','5142566435','Jeanne3@gmail.com')
INSERT INTO contacts VALUES ('Paul', 'lasne','4389525522','Paul4@gmail.com')
INSERT INTO contacts VALUES ('David', 'Compaore','5148374579','David5@gmail.com')
INSERT INTO contacts VALUES ('Jonathan', 'Clauss','5146471857','Jonathan6@gmail.com')
INSERT INTO contacts VALUES ('Khadija', 'Ndiaye','4388536389','Khadija7@gmail.com')
INSERT INTO contacts VALUES ('Sophie', 'Diop','5141853578','Sophie8@gmail.com')
INSERT INTO contacts VALUES ('Robert', 'Gomis','5144654954','Robert9@gmail.com')
INSERT INTO contacts VALUES ('Anne', 'Jenner','4388592580','Anne10@gmail.com')

INSERT INTO contacts VALUES ('Gerard', 'Pique','4385675894','Gerard11@gmail.com')
INSERT INTO contacts VALUES ('Alexandre', 'Mendy','5147959479','Alex12@gmail.com')
INSERT INTO contacts VALUES ('Emma', 'Rousseau','5146895846','Emma13@gmail.com')
INSERT INTO contacts VALUES ('Julie', 'Dupont','5141236477','Julie14@gmail.com')
INSERT INTO contacts VALUES ('Rose', 'Garcia','4384557888','Rose15@gmail.com')
INSERT INTO contacts VALUES ('Jordi', 'Peres','4384328647','Jordi16@gmail.com')
INSERT INTO contacts VALUES ('Juan', 'Meunier','5148479999','Juan17@gmail.com')
INSERT INTO contacts VALUES ('Stephane', 'Martinez','5144455785','Stephane18@gmail.com')
INSERT INTO contacts VALUES ('Elisa', 'Lacroix','4389875635','Elisa19@gmail.com')
INSERT INTO contacts VALUES ('Bernardo', 'Sylva','4383683793','Bernardo20@gmail.com')
INSERT INTO contacts VALUES ('Kendall', 'Jenner','8195567947','Kendall21@gmail.com')
INSERT INTO contacts VALUES ('Adil', 'Rami','4386853336','Adil22@gmail.com')
INSERT INTO contacts VALUES ('Rene', 'Leclerc','8196328648','Rene23@gmail.com')
INSERT INTO contacts VALUES ('Philipe', 'Bourgeois','5145680757','Philipe24@gmail.com')
INSERT INTO contacts VALUES ('Jose', 'Campos','4388894704','Jose25@gmail.com')



