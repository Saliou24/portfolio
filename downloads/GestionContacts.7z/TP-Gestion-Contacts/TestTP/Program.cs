﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestTP
{
    class Program
    {
        static readonly String connString = @"Data Source=751FJW2\SQLEXPRESS01;Initial Catalog=gestion_contacts;Integrated Security=True;Connect Timeout=30";
        public static void ConnectionData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString: connString))
            {
                conn.Open();
                Console.WriteLine("Connexion success!");
            }
        }
        public static bool CheckLogin(string counrriel, string passWord)
        {
            bool isLogin = false;
            using (SqlConnection conn = new SqlConnection(connectionString: connString))
            {
                conn.Open();
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = @"SELECT * FROM utilisateurs WHERE courriel=@Courriel AND mot_de_passe=@Mot_de_passe ";
                    cmd.Parameters.AddWithValue("@Courriel", counrriel);
                    cmd.Parameters.AddWithValue("@Mot_de_passe", passWord);

                    //string CourrielCheck = null;
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        return reader.HasRows;

                        //while (reader.Read())
                        //{
                        //    CourrielCheck = reader.GetString(0);
                        //    if (CourrielCheck == counrriel)
                        //    {
                        //        return true;
                        //    }
                        //    else
                        //    {
                        //        return false;
                        //    }
                        //}

                    }

                }

            }
            //return isLogin;
        }
        static void Main(string[] args)
        {

            ConnectionData();
            bool b = CheckLogin("Paul4@gmail.com", "tot");
            Console.WriteLine($" {b}");
            Console.ReadLine();
        }
    }
}
