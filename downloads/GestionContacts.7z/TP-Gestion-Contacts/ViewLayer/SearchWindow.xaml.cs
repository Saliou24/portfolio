﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using BussinessLayer;
using Modell;
using TP_Gestion_Contact;


namespace TP_Gestion_Contacts
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class SearchWindow : Window
    {
        public SearchWindow()
        {
            InitializeComponent();

            dataShowAll.ItemsSource = FuntionsLogic.ShowContacts();


        }

        private void BtSearch_Click(object sender, RoutedEventArgs e)
        {
            dataShowAll.ItemsSource = FuntionsLogic.SearchByyName(tbSearch.Text);
        }
        private void BtBackShowAll_Click(object sender, RoutedEventArgs e)
        {
            Window backFenetreMenu = new MenuWindow();
            backFenetreMenu.Visibility = Visibility.Visible;
            this.Close();
        }

        private void DataShowAll_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
